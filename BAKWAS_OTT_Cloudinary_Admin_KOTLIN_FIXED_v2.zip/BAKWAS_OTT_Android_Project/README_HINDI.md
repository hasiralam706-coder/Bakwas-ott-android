# BAKWAS OTT Android Project

## Build APK on GitHub (phone par ZIP extract nahi karna)
1. Upload `BAKWAS_OTT_Android_Project.zip` to the root of your GitHub repository.
2. Ensure `.github/workflows/build-apk.yml` is also present in the repository root. If it is inside the ZIP only, GitHub Actions will not discover it until the workflow file is separately committed at `.github/workflows/build-apk.yml`.
3. Open GitHub → Actions → **Build BAKWAS OTT APK** → Run workflow.
4. When finished, open the workflow run and download artifact `BAKWAS-OTT-debug-apk`.

## Cloudinary configuration
- Cloud name: `qarcxthn`
- Unsigned upload preset: `bakwas_ott_upload`
- The Admin panel offers photo and video selection and uploads selected media to Cloudinary.
- Cloudinary's unsigned preset must be configured as **Unsigned** in Cloudinary settings.

## Admin login in this prototype
- Username: `admin`
- Password: `Bakwas786`

**Security warning:** This is a client-side prototype login and is not secure against someone inspecting/modifying the APK. An unsigned Cloudinary preset can also be used by other people if they know its name. For real admin-only uploads, put authentication and Cloudinary API Secret on a trusted server and have the app request signed uploads. Never put the Cloudinary API Secret inside the Android app or share it in chat.

## Current limitations
- Uploaded media is sent to Cloudinary, but this version does not yet save a catalogue entry or display uploaded media in the home gallery automatically.
- Sample episode cards are demo data. Real video playback needs a playback URL/player integration.
