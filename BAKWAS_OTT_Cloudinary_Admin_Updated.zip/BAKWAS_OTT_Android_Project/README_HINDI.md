# BAKWAS OTT — Professional Android streaming demo

This project has a dark premium OTT-style Compose interface inspired by common streaming-app patterns. It is an independent demo and is not affiliated with JioHotstar.

## Included in this ZIP
- Premium home screen with featured hero, genre filters and horizontal content shelves
- Search across the sample catalogue
- Title details screen
- In-app streaming playback using AndroidX Media3 ExoPlayer and public sample streams
- My List / watchlist saved on the device
- Profile screen and Admin Studio entry
- Cloudinary image/video upload screen using the configured unsigned preset
- Kotlin `KeyboardOptions` import corrected to `androidx.compose.ui.text.input.KeyboardOptions`
- GitHub Actions workflow file kept as part of the project, but the repository's existing workflow YAML does not need to be changed

## Important configuration notes
- Cloudinary cloud name: `qarcxthn`
- Upload preset in the app: `bakwas_ott_upload`. Confirm that this exact unsigned preset exists in the Cloudinary dashboard.
- The sample catalogue streams public demo videos. Replace these URLs with media you own or are licensed to stream before publishing.
- Cloudinary uploads are not automatically added to a shared streaming catalogue. A backend and database/API are needed for that.
- The demo admin username/password are embedded in the APK and are not secure production authentication. Move admin authentication and privileged operations to a server before public release.
- Real offline downloads, live TV/sports, subscriptions, parental controls, profiles across devices, analytics, DRM and a server-managed catalogue require additional backend/service integration and are not claimed as implemented here.

## Build
Use the existing GitHub Actions workflow in the repository. The workflow should find this ZIP by the filename configured in its `find` step, extract it, and run `assembleDebug`.
