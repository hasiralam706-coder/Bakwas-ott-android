# BAKWAS OTT — Professional Android streaming demo

This project has a dark premium OTT-style Compose interface inspired by common streaming-app patterns. It is an independent demo and is not affiliated with JioHotstar.

## Included in this ZIP
- Premium home screen with featured hero, genre filters and horizontal content shelves
- Search across the sample catalogue
- Title details screen
- In-app streaming playback using AndroidX Media3 ExoPlayer and public sample streams
- My List / watchlist saved on the device
- Profile screen and Admin Studio entry
- Live & Events screen with sample playback (not real TV/sports feeds)
- Android Download Manager action for public sample MP4 files
- Subscription-plan UI (payment provider not connected)
- Device-local parental preference toggle
- Cloudinary image/video upload screen using the configured unsigned preset
- Kotlin `KeyboardOptions` import corrected to `androidx.compose.foundation.text.KeyboardOptions`
- GitHub Actions workflow file kept as part of the project, but the repository's existing workflow YAML does not need to be changed

## Important configuration notes
- Cloudinary cloud name: `qarcxthn`
- Upload preset in the app: `bakwas_ott_upload`. Confirm that this exact unsigned preset exists in the Cloudinary dashboard.
- The sample catalogue streams public demo videos. Replace these URLs with media you own or are licensed to stream before publishing.
- Cloudinary uploads are not automatically added to a shared streaming catalogue. A backend and database/API are needed for that.
- The demo admin username/password are embedded in the APK and are not secure production authentication. Move admin authentication and privileged operations to a server before public release.
- The download screen queues public sample MP4s using Android Download Manager. Live TV/sports feeds, paid subscriptions, enforceable parental controls, secure device-bound admin, profiles across devices, DRM, analytics and a shared server-managed catalogue require additional backend/service integration and are not claimed as production-ready here.

## Build
Use the existing GitHub Actions workflow in the repository. The workflow should find this ZIP by the filename configured in its `find` step, extract it, and run `assembleDebug`.


## Supabase catalogue connection (configured)
- Project URL: `https://mqmsbidtarppvzfoibyg.supabase.co`
- The Android app requests published rows from `public.movies` using the Supabase publishable key and only replaces the sample catalogue when published rows with a non-empty `video_url` are returned. If the API is unavailable, the sample catalogue remains visible.
- The publishable key is designed for client apps; it is not an admin/secret key. Never put a Supabase secret/service-role key in Android code. RLS must remain enabled.
- To add a title, insert a row in `public.movies` with `title`, `video_url`, and `is_published = true`; optionally set `description`, `poster_url`, `category`, and `release_year`. `video_url` must be a playable URL.
- If the API returns an exposure/schema error, open Supabase Dashboard → Project Settings / Integrations → Data API and ensure the `public` schema/table is exposed as needed. Do not turn off RLS.
- The current upload screen uploads media to Cloudinary but does not automatically create a row in `public.movies`; catalogue publishing is still a separate admin/backend step.
