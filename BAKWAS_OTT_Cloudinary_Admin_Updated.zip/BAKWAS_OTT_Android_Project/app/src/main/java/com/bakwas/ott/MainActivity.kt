package com.bakwas.ott

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private val Night = Color(0xFF080D19)
private val Navy = Color(0xFF101B31)
private val Card = Color(0xFF17243A)
private val Accent = Color(0xFF16B7FF)
private val Gold = Color(0xFFFFC857)
private val Muted = Color(0xFF9EACC2)
private const val CLOUD_NAME = "qarcxthn"
private const val UPLOAD_PRESET = "bakwas_ott_upload"
private const val ADMIN_USER = "admin"
private const val ADMIN_PASSWORD = "Bakwas786"

private data class ShowItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val year: String,
    val rating: String,
    val badge: String,
    val description: String,
    val videoUrl: String,
    val colors: List<Color>
)

private val catalog = listOf(
    ShowItem("bunny", "Big Buck Bunny", "A tiny hero. A huge adventure.", "Movies", "2008", "U", "EDITOR'S PICK", "A peaceful day turns into a colourful animated adventure. This sample title demonstrates the in-app streaming player.", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", listOf(Color(0xFF14532D), Color(0xFF65A30D))),
    ShowItem("elephant", "Elephant's Dream", "Enter a world beyond imagination", "Movies", "2006", "U/A 13+", "CULT CLASSIC", "A surreal animated short used here as a public sample stream for testing playback.", "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", listOf(Color(0xFF312E81), Color(0xFF7C3AED))),
    ShowItem("joyride", "For Bigger Joyrides", "Turn every moment up", "Trending", "Demo", "U", "TRENDING", "A short demo video to test playback and streaming behaviour on your device.", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4", listOf(Color(0xFF7C2D12), Color(0xFFF97316))),
    ShowItem("escape", "For Bigger Escape", "Adventure starts here", "Action", "Demo", "U/A 13+", "ACTION", "A sample action-themed video from the public Google demo media collection.", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4", listOf(Color(0xFF164E63), Color(0xFF0891B2))),
    ShowItem("tears", "Tears of Steel", "The future is not what it seems", "Sci-Fi", "2012", "U/A 13+", "FEATURED", "A science-fiction short film included as a sample streaming title.", "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", listOf(Color(0xFF1E293B), Color(0xFF475569))),
    ShowItem("sintel", "Sintel", "A journey worth remembering", "Drama", "2010", "U/A 13+", "AWARD WINNER", "A sample animated short that can be used to verify playback in the demo app.", "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", listOf(Color(0xFF7F1D1D), Color(0xFFBE123C)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BakwasApp(this) }
    }
}

@Composable
private fun BakwasApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("bakwas_prefs", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<ShowItem?>(null) }
    var playing by remember { mutableStateOf<ShowItem?>(null) }
    var searchMode by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("For You") }
    var watchlist by remember { mutableStateOf(prefs.getStringSet("watchlist", emptySet())?.toSet() ?: emptySet()) }
    var adminPage by remember { mutableStateOf(false) }
    var loggedIn by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf(ADMIN_USER) }
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var uploading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploading = true; status = "Photo upload ho raha hai…"
            scope.launch { status = withContext(Dispatchers.IO) { uploadToCloudinary(context, uri, "image") }; uploading = false }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploading = true; status = "Video upload ho raha hai…"
            scope.launch { status = withContext(Dispatchers.IO) { uploadToCloudinary(context, uri, "video") }; uploading = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, secondary = Gold, background = Night, surface = Card, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            when {
                playing != null -> PlayerScreen(context, playing!!, onBack = { playing = null })
                adminPage && !loggedIn -> AdminLogin(
                    username, { username = it }, password, { password = it }, status,
                    onBack = { adminPage = false; status = "" },
                    onLogin = { if (username == ADMIN_USER && password == ADMIN_PASSWORD) { loggedIn = true; status = "Login successful" } else status = "Username ya password galat hai" }
                )
                adminPage && loggedIn -> AdminPanel(
                    status, uploading, onBack = { adminPage = false; loggedIn = false; password = "" },
                    onPickImage = { imagePicker.launch("image/*") }, onPickVideo = { videoPicker.launch("video/*") }
                )
                selected != null -> DetailScreen(
                    item = selected!!, isSaved = watchlist.contains(selected!!.id),
                    onBack = { selected = null }, onPlay = { playing = selected },
                    onToggleSave = {
                        val updated = watchlist.toMutableSet()
                        if (!updated.add(selected!!.id)) updated.remove(selected!!.id)
                        watchlist = updated.toSet(); prefs.edit().putStringSet("watchlist", watchlist).apply()
                    }
                )
                else -> Scaffold(
                    containerColor = Night,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0C1424), contentColor = Color.White) {
                            listOf(Triple("Home", Icons.Default.Home, "Home"), Triple("Search", Icons.Default.Search, "Search"), Triple("Watchlist", Icons.Default.Bookmark, "My List"), Triple("Profile", Icons.Default.Person, "Profile")).forEach { (key, icon, label) ->
                                NavigationBarItem(selected = tab == key, onClick = { tab = key; searchMode = key == "Search" }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF17304A), unselectedIconColor = Muted, unselectedTextColor = Muted))
                            }
                        }
                    }
                ) { padding ->
                    when (tab) {
                        "Search" -> SearchPage(search, { search = it }, catalog.filter { it.title.contains(search, true) || it.category.contains(search, true) }, onOpen = { selected = it }, modifier = Modifier.padding(padding))
                        "Watchlist" -> WatchlistPage(catalog.filter { watchlist.contains(it.id) }, onOpen = { selected = it }, modifier = Modifier.padding(padding))
                        "Profile" -> ProfilePage(onAdmin = { adminPage = true; status = "" }, watchCount = watchlist.size, modifier = Modifier.padding(padding))
                        else -> HomePage(
                            category = category, onCategory = { category = it }, onSearch = { tab = "Search" },
                            onOpen = { selected = it }, onPlay = { playing = it }, modifier = Modifier.padding(padding)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomePage(category: String, onCategory: (String) -> Unit, onSearch: () -> Unit, onOpen: (ShowItem) -> Unit, onPlay: (ShowItem) -> Unit, modifier: Modifier = Modifier) {
    val hero = catalog.first()
    val visibleCatalog = if (category == "For You") catalog else catalog.filter { it.category.equals(category, ignoreCase = true) || (category == "Trending" && it.badge == "TRENDING") }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Accent, Color(0xFF3155D9)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("BAKWAS", fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp); Text("STREAM YOUR MOOD", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp) }
                IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
                Icon(Icons.Default.Cast, "Cast", tint = Muted, modifier = Modifier.padding(start = 4.dp))
            }
        }
        item { Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("For You", "Movies", "Trending", "Action", "Drama", "Sci-Fi").forEach { label ->
                val active = category == label
                Box(Modifier.clip(CircleShape).background(if (active) Accent else Card).clickable { onCategory(label) }.padding(horizontal = 17.dp, vertical = 9.dp)) { Text(label, color = if (active) Night else Muted, fontSize = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium) }
            }
        } }
        item {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(300.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(hero.colors + listOf(Night)))) {
                Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE050A12)))).padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoAwesome, null, tint = Gold, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(6.dp)); Text("${hero.badge}  •  ${hero.year}", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
                    Spacer(Modifier.height(8.dp)); Text(hero.title, fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text(hero.subtitle, color = Color(0xFFD7E3F4), fontSize = 13.sp, maxLines = 2)
                    Spacer(Modifier.height(14.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { onPlay(hero) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Night), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("Play now", fontWeight = FontWeight.Bold) }
                        OutlinedButton(onClick = { onOpen(hero) }, border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .65f)), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(Icons.Default.Info, null); Spacer(Modifier.width(5.dp)); Text("Details") }
                    }
                }
                Box(Modifier.align(Alignment.TopEnd).padding(16.dp).clip(CircleShape).background(Color.Black.copy(alpha = .35f)).padding(horizontal = 10.dp, vertical = 6.dp)) { Text("4K  •  DEMO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        }
        item { ContentRow(if (category == "For You") "Continue Watching" else "$category picks", visibleCatalog.take(3), onOpen, onPlay, showProgress = true) }
        item { ContentRow("Trending Now", (if (category == "For You") catalog.filter { it.id != hero.id } else visibleCatalog).take(5), onOpen, onPlay) }
        if (category == "For You") item { ContentRow("Critically Acclaimed", catalog.filter { it.category in listOf("Drama", "Sci-Fi", "Movies") }, onOpen, onPlay) }
        item { Column(Modifier.padding(horizontal = 18.dp)) { Text("Explore by genre", fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { listOf("Action" to Icons.Default.Bolt, "Comedy" to Icons.Default.EmojiEmotions, "Drama" to Icons.Default.TheaterComedy).forEach { (name, icon) -> Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Card).clickable { onCategory(name) }.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Accent, modifier = Modifier.size(25.dp)); Spacer(Modifier.height(7.dp)); Text(name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) } } } } }
    }
}

@Composable
private fun ContentRow(title: String, items: List<ShowItem>, onOpen: (ShowItem) -> Unit, onPlay: (ShowItem) -> Unit, showProgress: Boolean = false) {
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("See all  ›", color = Accent, fontSize = 12.sp) }
        Spacer(Modifier.height(12.dp)); LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.id }) { item ->
                Column(Modifier.width(148.dp).clickable { onOpen(item) }) {
                    Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(item.colors)), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Movie, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.size(40.dp)); Spacer(Modifier.height(8.dp)); Text(item.category.uppercase(), color = Color.White.copy(alpha = .75f), fontSize = 9.sp, letterSpacing = 1.sp) }
                        Box(Modifier.align(Alignment.TopStart).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = .38f)).padding(horizontal = 7.dp, vertical = 4.dp)) { Text(item.badge, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold) }
                        IconButton(onClick = { onPlay(item) }, modifier = Modifier.align(Alignment.BottomEnd).padding(7.dp).size(34.dp).clip(CircleShape).background(Color.White)) { Icon(Icons.Default.PlayArrow, null, tint = Night) }
                        if (showProgress) Box(Modifier.align(Alignment.BottomStart).padding(start = 9.dp, end = 9.dp, bottom = 8.dp).fillMaxWidth(.68f).height(3.dp).clip(CircleShape).background(Accent))
                    }
                    Spacer(Modifier.height(8.dp)); Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${item.year}  •  ${item.rating}", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SearchPage(query: String, onQuery: (String) -> Unit, results: List<ShowItem>, onOpen: (ShowItem) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp)) {
        Text("Discover", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Find your next favourite", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search movies, shows, genres…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, "Clear") } }, singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(16.dp)); Text("${results.size} titles", color = Muted, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 20.dp)) {
            items(results, key = { it.id }) { item ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { onOpen(item) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(92.dp, 112.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(item.colors)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                    Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("${item.year}  •  ${item.rating}  •  ${item.category}", color = Accent, fontSize = 11.sp); Spacer(Modifier.height(6.dp)); Text(item.subtitle, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }; Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun WatchlistPage(items: List<ShowItem>, onOpen: (ShowItem) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("My List", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Saved titles, all in one place", color = Muted); Spacer(Modifier.height(18.dp))
        if (items.isEmpty()) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.BookmarkBorder, null, tint = Accent, modifier = Modifier.size(54.dp)); Spacer(Modifier.height(12.dp)); Text("Your list is waiting", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Open a title and tap Add to My List.", color = Muted, fontSize = 13.sp) } } }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(items, key = { it.id }) { item -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { onOpen(item) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(80.dp, 98.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(item.colors)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Movie, null, tint = Color.White) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(item.title, fontWeight = FontWeight.Bold); Text(item.subtitle, color = Muted, fontSize = 12.sp, maxLines = 2); Text("${item.year} • ${item.category}", color = Accent, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
    }
}

@Composable
private fun ProfilePage(onAdmin: () -> Unit, watchCount: Int, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("My Space", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Your BAKWAS OTT experience", color = Muted)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF12385C), Color(0xFF30245C)))).padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(58.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Night, modifier = Modifier.size(34.dp)) }; Spacer(Modifier.width(14.dp)); Column { Text("Guest Viewer", fontWeight = FontWeight.Bold, fontSize = 20.sp); Text("Free demo profile", color = Color(0xFFD3E4F8), fontSize = 12.sp) } } }
        ProfileRow(Icons.Default.Bookmark, "My Watchlist", "$watchCount saved titles")
        ProfileRow(Icons.Default.Hd, "Streaming quality", "Adaptive / network dependent")
        ProfileRow(Icons.Default.Security, "Privacy & safety", "Demo profile stored on this device")
        Spacer(Modifier.height(4.dp)); Button(onClick = onAdmin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.AdminPanelSettings, null); Spacer(Modifier.width(8.dp)); Text("Admin Studio / Upload") }
        Text("BAKWAS OTT is an independent demo app. It is not affiliated with JioHotstar. Sample streams are provided for playback testing.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Card).padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) }
}

@Composable
private fun DetailScreen(item: ShowItem, isSaved: Boolean, onBack: () -> Unit, onPlay: () -> Unit, onToggleSave: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Box(Modifier.fillMaxWidth().height(340.dp).background(Brush.linearGradient(item.colors))) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(12.dp).clip(CircleShape).background(Color.Black.copy(alpha = .35f))) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Brush.verticalGradient(listOf(Color.Transparent, Night))).padding(20.dp)) { Text(item.badge, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp); Spacer(Modifier.height(8.dp)); Text(item.title, fontSize = 32.sp, fontWeight = FontWeight.Black); Text("${item.year}  •  ${item.rating}  •  ${item.category}", color = Color(0xFFD5E3F5), fontSize = 12.sp) }
        } }
        item { Column(Modifier.padding(20.dp)) { Text(item.subtitle, fontSize = 16.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(10.dp)); Text(item.description, color = Muted, fontSize = 14.sp, lineHeight = 21.sp); Spacer(Modifier.height(18.dp)); Button(onClick = onPlay, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Night)) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Play now", fontWeight = FontWeight.Bold) }; Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = onToggleSave, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(if (isSaved) Icons.Default.BookmarkAdded else Icons.Default.BookmarkAdd, null); Spacer(Modifier.width(8.dp)); Text(if (isSaved) "Remove from My List" else "Add to My List") }; Spacer(Modifier.height(22.dp)); Text("More like this", fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); catalog.filter { it.id != item.id }.take(3).forEach { related -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(12.dp)).background(Card).clickable { /* handled through home/search list */ }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(54.dp, 64.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(related.colors)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Movie, null, tint = Color.White) }; Spacer(Modifier.width(12.dp)); Column { Text(related.title, fontWeight = FontWeight.Bold); Text(related.subtitle, color = Muted, fontSize = 11.sp, maxLines = 1) } } } } }
    }
}

@Composable
private fun PlayerScreen(context: Context, item: ShowItem, onBack: () -> Unit) {
    val player = remember(item.id) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(item.videoUrl)); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Night)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }; Column(Modifier.weight(1f)) { Text(item.title, fontWeight = FontWeight.Bold, maxLines = 1); Text("Now streaming • Demo", color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.Cast, null, tint = Muted) }
        AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Column(Modifier.padding(18.dp)) { Text(item.title, fontSize = 24.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(6.dp)); Text("${item.year} • ${item.rating} • ${item.category}", color = Accent, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); Text(item.description, color = Muted, fontSize = 14.sp, lineHeight = 21.sp); Spacer(Modifier.height(20.dp)); Text("Playback tip", fontWeight = FontWeight.Bold); Text("A stable internet connection is recommended. These sample videos are for testing the player; connect your own licensed catalogue for a production launch.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun AdminLogin(username: String, onUsername: (String) -> Unit, password: String, onPassword: (String) -> Unit, status: String, onBack: () -> Unit, onLogin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("‹ Back", color = Accent, modifier = Modifier.clickable { onBack() }); Spacer(Modifier.height(10.dp)); Icon(Icons.Default.AdminPanelSettings, null, tint = Accent, modifier = Modifier.size(44.dp)); Text("Admin Studio", fontSize = 29.sp, fontWeight = FontWeight.Black); Text("Manage uploads for your demo catalogue", color = Muted)
        OutlinedTextField(value = username, onValueChange = onUsername, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = password, onValueChange = onPassword, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Secure sign in") }
        if (status.isNotBlank()) Text(status, color = if (status.contains("successful", true)) Color(0xFF86EFAC) else Gold)
        Text("Demo only: credentials embedded in an APK are not secure. Production admin access should use a server-side login and short-lived tokens.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun AdminPanel(status: String, uploading: Boolean, onBack: () -> Unit, onPickImage: () -> Unit, onPickVideo: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("‹ Back", color = Accent, modifier = Modifier.clickable { onBack() }); Spacer(Modifier.weight(1f)); Text("Admin Studio", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Text("Media centre", color = Muted); UploadTile("Upload a poster / photo", "JPG, PNG and other image formats", Icons.Default.AddPhotoAlternate, onPickImage, uploading); UploadTile("Upload a video", "Choose a video file from your phone", Icons.Default.VideoLibrary, onPickVideo, uploading)
        if (uploading) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Uploading to Cloudinary… keep the app open.", color = Muted, fontSize = 12.sp) }
        if (status.isNotBlank()) Text(status, color = if (status.contains("Uploaded successfully", true)) Color(0xFF86EFAC) else Gold, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp)); Text("Cloudinary cloud: $CLOUD_NAME", color = Muted, fontSize = 11.sp); Text("Upload preset: $UPLOAD_PRESET", color = Muted, fontSize = 11.sp)
        Text("Note: uploads are sent to Cloudinary, but this starter does not automatically publish them into a shared catalogue. A production app needs a secure backend/catalogue and server-side admin authentication.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun UploadTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, disabled: Boolean) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).clickable(enabled = !disabled) { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF153956)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent) }; Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) }
}

private fun uploadToCloudinary(context: Context, uri: Uri, resourceType: String): String {
    val boundary = "----Bakwas${UUID.randomUUID()}"
    var connection: HttpURLConnection? = null
    return try {
        val endpoint = URL("https://api.cloudinary.com/v1_1/$CLOUD_NAME/$resourceType/upload")
        connection = (endpoint.openConnection() as HttpURLConnection).apply { requestMethod = "POST"; doOutput = true; connectTimeout = 20000; readTimeout = 180000; setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary") }
        connection.outputStream.use { out ->
            fun field(name: String, value: String) { out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray(Charsets.UTF_8)) }
            field("upload_preset", UPLOAD_PRESET)
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"upload\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray(Charsets.UTF_8))
            context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out, bufferSize = 64 * 1024) } ?: throw IllegalStateException("Selected file open nahi hui")
            out.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code in 200..299) "Uploaded successfully. Cloudinary response: $response" else "Upload failed ($code): $response"
    } catch (e: Exception) { "Upload failed: ${e.message ?: "network error"}" } finally { connection?.disconnect() }
}
