package com.bakwas.ott

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private val Ink = Color(0xFF101014)
private val Panel = Color(0xFF1D1D24)
private val Red = Color(0xFFE53935)
private val Soft = Color(0xFFB9B9C2)
private const val CLOUD_NAME = "qarcxthn"
private const val UPLOAD_PRESET = "bakwas_ott_upload"
private const val ADMIN_USER = "admin"
private const val ADMIN_PASSWORD = "Bakwas786"

data class Episode(val title: String, val description: String, val season: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BakwasApp(this) }
    }
}

@Composable
fun BakwasApp(context: Context) {
    var selected by remember { mutableStateOf<Episode?>(null) }
    var search by remember { mutableStateOf("") }
    var adminPage by remember { mutableStateOf(false) }
    var loggedIn by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var uploading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val episodes = listOf(
        Episode("Roommates Ka Raita", "Do doston ki daily life aur comedy ka hungama.", "Season 1 • Episode 1"),
        Episode("Shaadi Mein Bawaal", "Ek wedding plan jo bilkul ulta pad gaya.", "Season 1 • Episode 2"),
        Episode("Mohalle Ka Superstar", "Mohalle mein fame paane ki funny koshish.", "Season 1 • Episode 3")
    )
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploading = true; status = "Photo upload ho raha hai…"
            scope.launch {
                status = withContext(Dispatchers.IO) { uploadToCloudinary(context, uri, "image") }
                uploading = false
            }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploading = true; status = "Video upload ho raha hai… bade video mein waqt lag sakta hai."
            scope.launch {
                status = withContext(Dispatchers.IO) { uploadToCloudinary(context, uri, "video") }
                uploading = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Ink, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            when {
                adminPage && !loggedIn -> Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("‹ Back", color = Red, modifier = Modifier.clickable { adminPage = false; status = "" })
                    Text("Admin Login", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
                    Button(onClick = { if (username == ADMIN_USER && password == ADMIN_PASSWORD) { loggedIn = true; status = "Login successful" } else status = "Username ya password galat hai" }, modifier = Modifier.fillMaxWidth()) { Text("Login") }
                    if (status.isNotBlank()) Text(status, color = Soft)
                    Text("Note: app ke andar rakha password production mein secure nahi hota. Admin-only access ke liye server authentication zaroori hai.", color = Soft, fontSize = 12.sp)
                }
                adminPage && loggedIn -> Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("‹ Back", color = Red, modifier = Modifier.clickable { adminPage = false; loggedIn = false; password = "" })
                        Spacer(Modifier.weight(1f)); Text("Admin Panel", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("Cloudinary Media Upload", color = Soft)
                    Button(onClick = { imagePicker.launch("image/*") }, enabled = !uploading, modifier = Modifier.fillMaxWidth()) { Text("Choose Photo & Upload") }
                    Button(onClick = { videoPicker.launch("video/*") }, enabled = !uploading, modifier = Modifier.fillMaxWidth()) { Text("Choose Video & Upload") }
                    if (uploading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (status.isNotBlank()) Text(status, color = if (status.contains("success", true) || status.contains("Uploaded", true)) Color(0xFF81C784) else Soft, fontSize = 13.sp)
                    Text("Upload preset: $UPLOAD_PRESET", color = Soft, fontSize = 12.sp)
                    Text("Unsigned upload preset ko public use se restrict nahi kiya ja sakta. Is login ko real security na samjhein.", color = Soft, fontSize = 12.sp)
                }
                selected == null -> LazyColumn(modifier = Modifier.fillMaxSize().background(Ink), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("BAKWAS", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Red)
                                Text("COMEDY • DRAMA • ENTERTAINMENT", fontSize = 10.sp, color = Soft, letterSpacing = 1.sp)
                            }
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                        }
                    }
                    item {
                        Box(Modifier.fillMaxWidth().height(175.dp).background(Panel, RoundedCornerShape(18.dp)).padding(18.dp), contentAlignment = Alignment.BottomStart) {
                            Column {
                                Text("NAYA EPISODE. NAYA BAWAAL.", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp)); Text("Har kahani mein kuch na kuch BAKWAS hai!", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Text("Original Comedy-Drama Series", color = Soft, fontSize = 12.sp)
                            }
                        }
                    }
                    item { OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Series ya episode search karein") }, singleLine = true, shape = RoundedCornerShape(14.dp)) }
                    item { Text("Trending Episodes", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    items(episodes.filter { it.title.contains(search, ignoreCase = true) }) { ep -> EpisodeCard(ep) { selected = ep } }
                    item {
                        Text("Categories", fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Comedy", "Drama", "Web Series").forEach { AssistChip(onClick = {}, label = { Text(it) }) } }
                    }
                    item { Button(onClick = { adminPage = true; status = "" }, modifier = Modifier.fillMaxWidth()) { Text("Admin Login / Upload") } }
                }
                else -> Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("‹ Back", color = Red, modifier = Modifier.clickable { selected = null })
                    Text(selected!!.title, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text(selected!!.season, color = Red); Text(selected!!.description, color = Soft)
                    Box(Modifier.fillMaxWidth().height(190.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Red, modifier = Modifier.size(68.dp)) }
                    Text("Video playback ke liye playback URL aur player integration configure karna hoga.", color = Soft)
                    Button(onClick = { selected = null }) { Text("Back to Home") }
                }
            }
        }
    }
}

private fun uploadToCloudinary(context: Context, uri: Uri, resourceType: String): String {
    val boundary = "----Bakwas${UUID.randomUUID()}"
    var connection: HttpURLConnection? = null
    return try {
        val endpoint = URL("https://api.cloudinary.com/v1_1/$CLOUD_NAME/$resourceType/upload")
        connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 20000; readTimeout = 120000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        connection.outputStream.use { out ->
            fun field(name: String, value: String) {
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray(Charsets.UTF_8))
            }
            field("upload_preset", UPLOAD_PRESET)
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"upload\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray(Charsets.UTF_8))
            context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out, bufferSize = 64 * 1024) }
                ?: throw IllegalStateException("Selected file open nahi hui")
            out.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code in 200..299) "Uploaded successfully. Cloudinary response: $response" else "Upload failed ($code): $response"
    } catch (e: Exception) { "Upload failed: ${e.message ?: "network error"}" }
    finally { connection?.disconnect() }
}

@Composable
fun EpisodeCard(ep: Episode, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 104.dp, height = 78.dp).background(Color(0xFF34343D), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, contentDescription = "Play episode", tint = Red, modifier = Modifier.size(34.dp)) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
            Text(ep.title, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(ep.season, color = Red, fontSize = 11.sp); Text(ep.description, color = Soft, fontSize = 12.sp, maxLines = 2)
        }
    }
}
